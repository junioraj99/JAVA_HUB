public class Veena {

	public void play() {
		System.out.println("Veena");
	}
}
