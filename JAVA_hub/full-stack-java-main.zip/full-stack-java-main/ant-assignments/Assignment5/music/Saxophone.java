public class Saxophone {

	public void play() {
		System.out.println("Saxophone");
	}
}	
