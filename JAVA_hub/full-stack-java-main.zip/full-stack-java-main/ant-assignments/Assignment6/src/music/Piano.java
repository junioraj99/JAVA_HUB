package music;

public class Piano {

	public void play() {
		System.out.println("Piano");
	}
}
