package music;

public class Guitar {

	public static void main(String[] args) {
		new Guitar().play();
		new Piano().play();
		new Saxophone().play();
		new Veena().play();
		new Flute().play();

	}
	public void play() {
		System.out.println("Play Guitar");
	}
}
