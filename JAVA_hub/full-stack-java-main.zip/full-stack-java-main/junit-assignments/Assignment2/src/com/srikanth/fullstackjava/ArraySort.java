package com.srikanth.fullstackjava;

import java.util.Arrays;

public class ArraySort {

	public int[] sortNumbers(int [] arr) {
		Arrays.sort(arr);
		return arr;
	}
}
