package com.srikanth.fullstackjava;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	AccountDetailsTest1.class,
	AccountDetailsTest2.class
})

public class TestSuite {

}
