INSERT INTO cd (cd_id, cd_title, cd_price, cd_publisher) VALUES (100, 'Java8', 500, 'Oracle')
INSERT INTO cd (cd_id, cd_title, cd_price, cd_publisher) VALUES (101, 'Tomcat', 400, 'Apache')
INSERT INTO cd (cd_id, cd_title, cd_price, cd_publisher) VALUES (102, 'Spring Data', 1000, 'Spring Org')
INSERT INTO cd (cd_id, cd_title, cd_price, cd_publisher) VALUES (103, 'Maven', 300, 'Apache')
INSERT INTO cd (cd_id, cd_title, cd_price, cd_publisher) VALUES (104, 'Hibernate', 800, 'JBoss')


