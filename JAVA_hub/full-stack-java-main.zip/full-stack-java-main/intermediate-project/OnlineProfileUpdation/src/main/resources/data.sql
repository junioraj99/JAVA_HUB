/*
insert into user_details (user_id, password, user_type) values ('sr20000959', '1234', 'Employee');
insert into user_details (user_id, password, user_type) values ('ka1890', '1234', 'Employee');
insert into user_details (user_id, password, user_type) values ('kn87474', '1234', 'Employee');
insert into user_details (user_id, password, user_type) values ('nt14560', '1234', 'Admin');

insert into job_details (job_id, job_name, job_description, project_name, required_skills,
optional_skills, location, employee_band, experience, positions, email_id, contact_number)
values (1, 'java developer', 'coding, unit testing', 'merival', 'java, spring, oracle', 'hibernate, angular',
'bangalore', 'b2', 3, 20, 'nt14560@gmail.com', 9654286749);
insert into job_details (job_id, job_name, job_description, project_name, required_skills,
optional_skills, location, employee_band, experience, positions, email_id, contact_number)
values (2, 'ui developer', 'design, unit testing', 'merival', 'html, angular, javascript', 'java, oracle',
'chennai', 'b1', 2, 50, 'nt14560@gmail.com', 9654286749);
insert into job_details (job_id, job_name, job_description, project_name, required_skills,
optional_skills, location, employee_band, experience, positions, email_id, contact_number)
values (3, 'full stack developer', 'design, coding, unit testing', 'merival', 'java, spring boot, html, angular, 
javascript', 'jenkins, cloud', 'hyderabad', 'b3', 6, 20, 'nt14560@gmail.com', 9654286749);

insert into profile_details(profile_id, user_id, first_name, last_name, skill_set, location, dob, 
qualification, experience, gender, phone_number, email_id) 
values (1, 'sr20000959', 'srikanth', 'naidu', 'java', 'bangalore', '15/06/1989', 'b.tech', 6, 
'Male', '9959656462', 'sr20000959@gmail.com');
insert into profile_details(profile_id, user_id, first_name, last_name, skill_set, location, dob, 
qualification, experience, gender, phone_number, email_id) 
values (2, 'ka1890', 'kiran', 'kumar', 'oracle', 'chennai', '17/04/1989', 'b.tech', 4, 
'Male', '96336315632', 'ka1890@gmail.com');
insert into profile_details(profile_id, user_id, first_name, last_name, skill_set, location, dob, 
qualification, experience, gender, phone_number, email_id) 
values (3, 'kn87474', 'kiran', 'naidu', 'java', 'bangalore', '9/12/1989', 'm.tech', 4, 
'Male', '9526295378', 'kn87474@gmail.com');
*/