package assignment2;

public class InstrumentMain {
	
	public static void main(String[] args) {
		Instrument instrument = new Instrument();
		instrument.play();
		instrument.playParent();
	}
}
