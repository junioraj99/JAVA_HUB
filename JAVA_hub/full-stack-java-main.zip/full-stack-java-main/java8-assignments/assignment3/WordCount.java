package assignment3;

@FunctionalInterface
public interface WordCount {

	int count(String str);
}
