## Full Stack Developer Assignments:

## 1. Developer Details:

- Srikanth Sambirli
- Full Stack Java and AWS Developer
- Bangalore, India


## 2. List Of Assignments:

1. HTML5 - Assignments

2. JavaScript - Assignments

3. AngularJS-L1 - Assignments

4. Java 8 - Assignments

5. Oracle PLSQL - Assignments

6. Hibernate- Assignments

7. Spring Basics - Assignments

8. JUnit - Assignments

9. RESTful Web Services Basics - Assignments

10. ANT - Assignments

11. Maven Exercises

12. Spring Boot - Assignments

13. Spring Data


## 3. Intermediate Project:

Project Title: Employee Profile Updation

Scope:
Online profile updating Application is intended to be used by the employee of the organization over the internet. This Application provides two types of users such as Administrator and Employee. Administrator user  is responsible to add or delete the  job Details of the specific project  along with various parameters such as Job Code, Skill Set, location, Number of years of experience etc. Employee user can search/view the Job details and add/delete/modify the profile details along with various other parameters.
The application does not expect authentication or authorization of the end users. It goes by the assumption that the users are already registered and hence can simply login using their user ID provided by the Organization.

Code Path: 

## 4. Final Project:

Project Title: Account Management System

Scope:
1. Customer can have one or more bank accounts (Eg: ICICI,HDFC..).
2. Transfer amount from one account to another account.
3. Create CRUD operations for Customer and Accounts.
4. Develop customer login , after successful login show accounts summary. Click on account display account information available balance.
5. Transactions Filter/Search operation from date - to date show Transaction summary.

Code Path: 
