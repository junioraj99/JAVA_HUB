package com.srikanth.fullstackjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStarterApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringStarterApp.class, args);
	}
}
