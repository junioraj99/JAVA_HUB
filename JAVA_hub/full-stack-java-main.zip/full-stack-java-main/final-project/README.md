Final Project for Java Full Stack Developer:
--------------------------------------------

## Application Name: Online Account Management System

- Srikanth Sambirli
- Java Full Stack Developer
- Bangalore, India

## Technologies Used

Java 8, Spring Boot, Html5, Spring JPA, MySql, Spring Restful Webservices

## For accessing the home page of the application

http://localhost:8001




